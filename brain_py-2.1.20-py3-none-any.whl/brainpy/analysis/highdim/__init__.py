# -*- coding: utf-8 -*-

from .slow_points import *
