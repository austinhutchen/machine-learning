# -*- coding: utf-8 -*-


__all__ = [
  'DSAnalyzer'
]


class DSAnalyzer(object):
  """Base class of analyzers for dynamical systems in BrainPy"""
  pass

