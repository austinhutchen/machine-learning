# -*- coding: utf-8 -*-

from ..base import Integrator


class PDEIntegrator(Integrator):
  pass

