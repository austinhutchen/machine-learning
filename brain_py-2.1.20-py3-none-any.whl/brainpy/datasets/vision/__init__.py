# -*- coding: utf-8 -*-

from .mnist import *

